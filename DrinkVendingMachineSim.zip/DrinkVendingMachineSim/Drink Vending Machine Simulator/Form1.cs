﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace Drink_Vending_Machine_Simulator
{
    public partial class drinkVendingMachineForm : Form
    {
        public drinkVendingMachineForm()
        {
            InitializeComponent();
        }

        private void drinkVendingMachineForm_Load(object sender, EventArgs e)
        {
            int count = 20;
            decimal zeroSales = 0m;
            colaLabel.Text = count.ToString();
            rootBeerLabel.Text = count.ToString();
            lemonLimeLabel.Text = count.ToString();
            grapeSodaLabel.Text = count.ToString();
            creamSodaLabel.Text = count.ToString();
            totalLabel.Text = zeroSales.ToString("c");
        }

        decimal sales;
        decimal total = 0m;
        int totalColaCount = 20;
        int totalRootBeerCount = 20;
        int totalLemonLimeCount = 20;
        int totalGrapeSodaCount = 20;
        int totalCreamSodaCount = 20;

        object[,] softDrink = new object[,]
        {
                    {"Cola", 1.0m, 20 },
                    {"Root Beer", 1.0m, 20 },
                    {"Lemon Lime", 1.0m, 20 },
                    { "Grape Soda", 1.50m, 20 },
                    { "Cream Soda", 1.50m, 20 },
            };

        private void colaPictureBox_Click(object sender, EventArgs e)
        {
            int count;

            Drink cola = new Drink();

            cola.Name = (string)softDrink[0, 0];
            cola.Cost = (decimal)softDrink[0, 1];
            cola.Amount = (int)softDrink[0, 2];

            if (totalColaCount > 0)
            {
                cola.Amount = (int)softDrink[0, 2];

                count = cola.Amount - 1;

                totalColaCount = count;

                softDrink[0, 2] = totalColaCount;

                sales = cola.Cost;

                total += sales;

                colaLabel.Text = totalColaCount.ToString();

                totalLabel.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sorry, " + cola.Name + " is sold out.");
            }
        }

        private void rootBeerPictureBox_Click(object sender, EventArgs e)
        {
            int count;

            Drink rootBeer = new Drink();

            rootBeer.Name = (string)softDrink[1, 0];
            rootBeer.Cost = (decimal)softDrink[1, 1];
            rootBeer.Amount = (int)softDrink[1, 2];

            if (totalRootBeerCount > 0)
            {
                rootBeer.Amount = (int)softDrink[1, 2];

                count = rootBeer.Amount - 1;

                totalRootBeerCount = count;

                softDrink[1, 2] = totalRootBeerCount;

                sales = rootBeer.Cost;

                total += sales;

                rootBeerLabel.Text = totalRootBeerCount.ToString();

                totalLabel.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sorry, " + rootBeer.Name + " is sold out.");
            }
        }
        private void lemonLimePictureBox_Click(object sender, EventArgs e)
        {
            int count;

            Drink lemonLime = new Drink();

            lemonLime.Name = (string)softDrink[2, 0];
            lemonLime.Cost = (decimal)softDrink[2, 1];
            lemonLime.Amount = (int)softDrink[2, 2];

            if (totalLemonLimeCount > 0)
            {
                lemonLime.Amount = (int)softDrink[2, 2];

                count = lemonLime.Amount - 1;

                totalLemonLimeCount = count;

                softDrink[2, 2] = totalLemonLimeCount;

                sales = lemonLime.Cost;

                total += sales;

                lemonLimeLabel.Text = totalLemonLimeCount.ToString();

                totalLabel.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sorry, " + lemonLime.Name + " is sold out.");
            }
        }
        private void grapeSodaPictureBox_Click(object sender, EventArgs e)
        {
            int count;

            Drink grapeSoda = new Drink();

            grapeSoda.Name = (string)softDrink[3, 0];
            grapeSoda.Cost = (decimal)softDrink[3, 1];
            grapeSoda.Amount = (int)softDrink[3, 2];

            if (totalGrapeSodaCount > 0)
            {
                grapeSoda.Amount = (int)softDrink[3, 2];

                count = grapeSoda.Amount - 1;

                totalGrapeSodaCount = count;

                softDrink[3, 2] = totalGrapeSodaCount;

                sales = grapeSoda.Cost;

                total += sales;

                grapeSodaLabel.Text = totalGrapeSodaCount.ToString();

                totalLabel.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sorry, " + grapeSoda.Name + " is sold out.");
            }
        }
        private void creamSodaPictureBox_Click(object sender, EventArgs e)
        {
            int count;

            Drink creamSoda = new Drink();

            creamSoda.Name = (string)softDrink[4, 0];
            creamSoda.Cost = (decimal)softDrink[4, 1];
            creamSoda.Amount = (int)softDrink[4, 2];

            if (totalCreamSodaCount > 0)
            {
                creamSoda.Amount = (int)softDrink[4, 2];

                count = creamSoda.Amount - 1;

                totalCreamSodaCount = count;

                softDrink[4, 2] = totalCreamSodaCount;

                sales = creamSoda.Cost;

                total += sales;

                creamSodaLabel.Text = totalCreamSodaCount.ToString();

                totalLabel.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sorry, " + creamSoda.Name + " is sold out.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
